import pyodbc
from flask import Flask, jsonify, request
from flask_cors import CORS
import os
import traceback  # Import traceback module for error logging
import cv2
import numpy as np
from PIL import Image
import io
import sys
import pickle
import face_recognition

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

connection_string = 'DRIVER={SQL Server};SERVER=MARCO\MARCO;DATABASE=photo_database;Trusted_Connection=yes;'
conn = pyodbc.connect(connection_string)
cursor = conn.cursor()


def add_User_Encoding(photoUrl):
    image_face = face_recognition.load_image_file(photoUrl)
    face_encoding = face_recognition.face_encodings(image_face)
    face_encoding_binary = pickle.dumps(face_encoding)
    return face_encoding_binary


def verifyFace(photoUrl):
    image_face = face_recognition.loadimage(photoUrl)
    face_encoding = face_recognition.face_encodings(image_face)
    return face_encoding

def compareFaces(knownEncoding, newEncoding):
    results = face_recognition.compare_faces(knownEncoding, newEncoding)
    if any(results):
        return True
    return False

@app.route('/getData', methods=['GET'])
def get_data():
    try:
        cursor.execute("SELECT * FROM temp")
        data = cursor.fetchall()
        data_dict = [{'id': row.id, 'photo_url': row.photo_url} for row in data]
        return jsonify(data_dict)
    except Exception as e:
        traceback.print_exc()  
        return jsonify({'error': str(e)}), 500
    
@app.route('/getData/<int:id>', methods=['GET'])
def get_id_data(id):
    try:
        cursor.execute(f"Select * FROM temp where id = ?",(id,))
        data = cursor.fetchone()
        data_dict = [{'id': data.id, 'photo_url': data.photo_url}]
        return jsonify(data_dict)
    except Exception as e:
        traceback.print_exc()  
        return jsonify({'error': str(e)}), 500
    
    
@app.route('/adicionarUtente', methods=['POST'])
def add_utente():
    try:
        if 'photo' not in request.files:
            return jsonify({'error': 'No file part'}),400
        
        photoFile = request.files['photo']
        nomeUtente = request.form.get('nomeUtente')
        valencia = request.form.get('valencia')
        sala = request.form.get('sala')
        autorizacao = request.form.get('autorizacao')
        
        if not (photoFile and nomeUtente and valencia and sala and autorizacao):
            return jsonify({'error': 'Missing required fields'}), 400
        
        try:
            autorizacao = int(autorizacao)
        except ValueError:
            return jsonify({'error': 'not a number'}),400
        
        if autorizacao <1 or autorizacao > 3:
            return jsonify({'error':'Autorizacao deve ser entre 1 e 3'}), 400
        
        if photoFile.filename == '':
            return jsonify({'error': 'Selecione uma imagem'}),400
        
        photoPath = os.path.join('C:\\Users\\marco\\Desktop', photoFile.filename)
        photoFile.save(photoPath)

        face_encoding = add_User_Encoding(photoPath)
        
        cursor.execute(f'SELECT * from UTENTE')
        if cursor.rowcount == 0:
            cursor.execute(f'INSERT INTO UTENTE (nome, valencia, sala, Autorização) VALUES (?, ?, ?, ?)', (nomeUtente, valencia, sala, autorizacao))
            conn.commit()
        else:         
            for row in cursor.execute(f'SELECT nome FROM UTENTE'):
                if nomeUtente == row[0]:
                    cursor.execute(f'SELECT idUtente FROM UTENTE where nome = ?',(nomeUtente))
                    idUtente = cursor.fetchone()[0]
                    cursor.execute(f'INSERT INTO ENCODING (encoding, UTENTEidUtente) VALUES(?,?)', (face_encoding, idUtente))
                    conn.commit()
            
        return jsonify({'message': 'Photo uploaded successfully', 'photo_path': photoPath})

    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500


                    
@app.route('/obterDadosUtente/<int:id>', methods=['GET'])
def get_data_user(id):
    try:
        cursor.execute(f'SELECT * FROM UTENTE WHERE idUtente = ?', (id))
        data = cursor.fetchone()        
        cursor.execute(f'SELECT * FROM ENCODING WHERE UTENTEidUtente = ?',(id))
        dataEncoding = cursor.fetchone()
        face_encoding = pickle.loads(dataEncoding.encoding)
        data_dict_encoding = [{'nome': data.nome,'utenteID:': dataEncoding.UTENTEidUtente}]
        return jsonify(data_dict_encoding)
    
    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500

@app.route('/VerificarExisteUtente', methods=['POST'])
def verify_user():
    try:
        if 'photo' not in request.files:
            return jsonify({'error': 'No file part'}),400
        
        photoFile = request.files['photo']
        
        photoPath = os.path.join('C:\\Users\\marco\\Desktop', photoFile.filename)
        photoFile.save(photoPath)

        encoding = verify_user(photoFile)
        
        for index, row in enumerate(cursor.execute(f'SELECT encoding FROM ENCODING')):
            encodingDatabase = pickle.loads(row[index])
            
            
    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500
                    

@app.route('/sendPhoto', methods=['POST'])
def add_photo_url():
    try:
        if 'photo' not in request.files:
            return jsonify({'error': 'No file part'}), 400

        photo_file = request.files['photo']

        if photo_file.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        if photo_file:
            photo_path = os.path.join('C:\\Users\\marco\\Desktop', photo_file.filename)
            photo_file.save(photo_path)

            cursor.execute(f'INSERT INTO temp (photo_url) VALUES (?)', (photo_path,))
            conn.commit()

            return jsonify({'message': 'Photo uploaded successfully', 'photo_path': photo_path})

    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500

    
@app.route('/data', methods=['PUT'])
def add_data():
    try:
        photo_URL = request.json['photo_url']
        cursor.execute("INSERT INTO temp (photo_url) VALUES (?)", (photo_URL,))
        conn.commit()
        return jsonify({'message': 'Data added successfully'})
    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500

@app.route('/data/<int:id>', methods=['PUT'])
def update_data(id):
    try:
        photo_URL = request.json['photo_url']
        cursor.execute("UPDATE temp SET photo_url = ? WHERE id = ?", (photo_URL, id))
        conn.commit()
        return jsonify({'message': 'Data updated successfully'})
    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500

@app.route('/data/<int:id>', methods=['DELETE'])
def delete_data(id):
    try:
        cursor.execute("DELETE FROM temp WHERE id = ?", (id,))
        conn.commit()
        return jsonify({'message': 'Data deleted successfully'})
    except Exception as e:
        traceback.print_exc() 
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
