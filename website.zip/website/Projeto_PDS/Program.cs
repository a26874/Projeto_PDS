﻿using System;
using System.Collections.Generic;
using System.Text.Json;

namespace Projeto_PDS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Qtd:");
            int qtdNumbers = 0;
            try
            {
                qtdNumbers = Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            long temp= 0, number= 0, result = 0;

            for (int i = 0; i < qtdNumbers ; i++) {
                result = number + temp;
                if (number == 0)
                    number++;
                temp = number;
                number = result;
                Console.WriteLine(result.ToString());
            }
        }
    }
}
